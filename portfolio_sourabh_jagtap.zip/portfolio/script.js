/* ═══════════════════════════════════════════════════════
   SOURABH JAGTAP — PORTFOLIO SCRIPT
   All interactions, animations & features
═══════════════════════════════════════════════════════ */

// ── Wait for DOM ──
document.addEventListener('DOMContentLoaded', () => {

  /* ══════════════════════════════
     1. SCROLL PROGRESS BAR
  ══════════════════════════════ */
  const progressBar = document.getElementById('scroll-progress');

  function updateProgress() {
    const scrollTop  = window.scrollY;
    const docHeight  = document.documentElement.scrollHeight - window.innerHeight;
    const percent    = (scrollTop / docHeight) * 100;
    progressBar.style.width = percent + '%';
  }

  /* ══════════════════════════════
     2. NAVBAR — blur on scroll
  ══════════════════════════════ */
  const navbar = document.getElementById('navbar');

  function updateNavbar() {
    if (window.scrollY > 60) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  }

  /* ══════════════════════════════
     3. BACK TO TOP BUTTON
  ══════════════════════════════ */
  const backBtn = document.getElementById('back-to-top');

  backBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  function updateBackBtn() {
    if (window.scrollY > 400) {
      backBtn.classList.add('visible');
    } else {
      backBtn.classList.remove('visible');
    }
  }

  /* ══════════════════════════════
     4. SCROLL LISTENER (batched)
  ══════════════════════════════ */
  window.addEventListener('scroll', () => {
    updateProgress();
    updateNavbar();
    updateBackBtn();
  }, { passive: true });

  // Run once on load
  updateProgress();
  updateNavbar();
  updateBackBtn();

  /* ══════════════════════════════
     5. INTERSECTION OBSERVER — reveal animations
  ══════════════════════════════ */
  const reveals = document.querySelectorAll('.reveal, .fade-up');

  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        // Once revealed, no need to watch anymore
        revealObserver.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.12,
    rootMargin: '0px 0px -50px 0px'
  });

  reveals.forEach(el => revealObserver.observe(el));

  // Hero elements reveal immediately
  document.querySelectorAll('.fade-up').forEach((el, i) => {
    setTimeout(() => el.classList.add('visible'), 100 + i * 150);
  });

  /* ══════════════════════════════
     6. TYPED TEXT ANIMATION
  ══════════════════════════════ */
  const typedEl   = document.querySelector('.typed-text');
  const phrases   = [
    'Engineering Student',
    'Python Developer',
    'AI Enthusiast',
    'Space Explorer 🔭',
    'Creative Thinker ✏️'
  ];
  let phraseIndex = 0;
  let charIndex   = 0;
  let isDeleting  = false;
  let typingTimer;

  function type() {
    const current = phrases[phraseIndex];
    if (!typedEl) return;

    if (isDeleting) {
      typedEl.textContent = current.substring(0, charIndex - 1);
      charIndex--;
    } else {
      typedEl.textContent = current.substring(0, charIndex + 1);
      charIndex++;
    }

    let speed = isDeleting ? 55 : 90;

    if (!isDeleting && charIndex === current.length) {
      // Pause at end
      speed = 1800;
      isDeleting = true;
    } else if (isDeleting && charIndex === 0) {
      isDeleting = false;
      phraseIndex = (phraseIndex + 1) % phrases.length;
      speed = 350;
    }

    typingTimer = setTimeout(type, speed);
  }

  type();

  /* ══════════════════════════════
     7. DARK / LIGHT MODE TOGGLE
  ══════════════════════════════ */
  const themeToggle = document.getElementById('theme-toggle');
  const html        = document.documentElement;

  // Check saved preference
  const savedTheme = localStorage.getItem('sj-theme') || 'light';
  html.setAttribute('data-theme', savedTheme);

  themeToggle.addEventListener('click', () => {
    const current = html.getAttribute('data-theme');
    const next    = current === 'light' ? 'dark' : 'light';
    html.setAttribute('data-theme', next);
    localStorage.setItem('sj-theme', next);
  });

  /* ══════════════════════════════
     8. MOBILE HAMBURGER MENU
  ══════════════════════════════ */
  const hamburger  = document.getElementById('hamburger');
  const mobileMenu = document.getElementById('mobileMenu');

  hamburger.addEventListener('click', () => {
    const isOpen = mobileMenu.classList.toggle('open');
    hamburger.classList.toggle('open', isOpen);
  });

  // Close menu when a link is tapped
  document.querySelectorAll('.mob-link').forEach(link => {
    link.addEventListener('click', () => {
      mobileMenu.classList.remove('open');
      hamburger.classList.remove('open');
    });
  });

  /* ══════════════════════════════
     9. SMOOTH SCROLL for nav links
  ══════════════════════════════ */
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        const offset = parseInt(getComputedStyle(document.documentElement)
          .getPropertyValue('--nav-h')) || 68;
        const top = target.getBoundingClientRect().top + window.scrollY - offset;
        window.scrollTo({ top, behavior: 'smooth' });
      }
    });
  });

  /* ══════════════════════════════
     10. CERTIFICATE MODAL
  ══════════════════════════════ */
  const modal      = document.getElementById('modal-overlay');
  const modalImg   = document.getElementById('modal-img');
  const modalCap   = document.getElementById('modal-caption');
  const modalClose = document.getElementById('modal-close');

  document.querySelectorAll('.cert-card').forEach(card => {
    card.addEventListener('click', () => {
      const imgSrc = card.getAttribute('data-img');
      const title  = card.getAttribute('data-title');
      modalImg.src    = imgSrc;
      modalImg.alt    = title;
      modalCap.textContent = title;
      modal.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  });

  function closeModal() {
    modal.classList.remove('open');
    document.body.style.overflow = '';
    setTimeout(() => { modalImg.src = ''; }, 300);
  }

  modalClose.addEventListener('click', closeModal);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeModal();
  });

  /* ══════════════════════════════
     11. BUTTON RIPPLE EFFECT
  ══════════════════════════════ */
  document.querySelectorAll('.btn').forEach(btn => {
    btn.addEventListener('click', function (e) {
      const rect   = this.getBoundingClientRect();
      const x      = e.clientX - rect.left;
      const y      = e.clientY - rect.top;
      const ripple = document.createElement('span');
      ripple.style.cssText = `
        position:absolute;
        border-radius:50%;
        transform:scale(0);
        animation:ripple-anim 0.55s linear;
        background:rgba(255,255,255,0.35);
        width:80px; height:80px;
        left:${x - 40}px; top:${y - 40}px;
        pointer-events:none;
      `;
      this.style.position = 'relative';
      this.style.overflow = 'hidden';
      this.appendChild(ripple);
      setTimeout(() => ripple.remove(), 600);
    });
  });

  // Inject ripple keyframe
  const style = document.createElement('style');
  style.textContent = `
    @keyframes ripple-anim {
      to { transform: scale(4); opacity: 0; }
    }
  `;
  document.head.appendChild(style);

  /* ══════════════════════════════
     12. ACTIVE NAV LINK on scroll
  ══════════════════════════════ */
  const sections  = document.querySelectorAll('section[id]');
  const navAnchors = document.querySelectorAll('.nav-links a');

  const sectionObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        navAnchors.forEach(a => a.removeAttribute('style'));
        const active = document.querySelector(`.nav-links a[href="#${entry.target.id}"]`);
        if (active) active.style.color = 'var(--accent)';
      }
    });
  }, { rootMargin: '-40% 0px -55% 0px' });

  sections.forEach(s => sectionObserver.observe(s));

  /* ══════════════════════════════
     13. PARALLAX — hero orbs on mouse
  ══════════════════════════════ */
  document.addEventListener('mousemove', (e) => {
    const { innerWidth: w, innerHeight: h } = window;
    const x = (e.clientX / w - 0.5) * 30;
    const y = (e.clientY / h - 0.5) * 20;

    const orbs = document.querySelectorAll('.orb');
    orbs.forEach((orb, i) => {
      const factor = (i + 1) * 0.6;
      orb.style.transform = `translate(${x * factor}px, ${y * factor}px)`;
    });
  });

});
